const mongoose = require('mongoose')

const eleveSchema = mongoose.Schema(
    {
        nom: {
            type: String,
            required: [true, "entrez le nom"]
        },
        prenom: {
            type: String
        },
        tel: {
            type: Number,
            required: true
        },
        email: {
            type: String
        
        },
        image: {
            type: String,
            required: false
        }
    },
    {
        timestamps: true
    }
)

const Eleve = mongoose.model('Eleve', eleveSchema);
module.exports = Eleve;