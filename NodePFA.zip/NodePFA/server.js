const express = require('express')
const mongoose = require('mongoose')
const Eleve = require('./models/EleveModel')
const app = express()

app.use(express.json())
app.use(express.urlencoded({extended: false}))

//routes
app.get('/', (req,res) => {
    res.send('hello node js')
})
app.get('/blog', (req,res) => {
    res.send('hello blogin blog')
})


app.get('/eleves', async(req,res) => {
    try {
        const eleves = await Eleve.find({});
        res.status(200).json(eleves);
    } catch(error) {
        res.status(500).json({message: error.message}) 
    }
})
app.get('/eleves/:id', async(req,res) => {
    try {
        const {id} = req.params;
        const eleves = await Eleve.findById(id);
        res.status(200).json(eleves);
    } catch(error) {
        res.status(500).json({message: error.message}) 
    }
})

app.post('/eleves', async(req,res) => {
   try {
    const eleve = await Eleve.create(req.body)
    res.status(200).json(eleve);

   }catch(error) {
    console.log(error.message);
    res.status(500).json({message: error.message})
   }
})
app.put('/eleves/:id', async(req,res) => {
    try {
        const {id} = req.params;
        const eleve = await Eleve.findByIdAndUpdate(id, req.body);
        if(!Eleve) {
        return res.status(404).json({message: `cannot find any eleve with ID ${id}`}) 
        }
        const updateEleve = await Eleve.findById(id); 
        res.status(200).json(updateEleve);
    } catch(error) {
        res.status(500).json({message: error.message}) 
    }
})
app.delete('/eleves/:id', async(req,res) => {
    try {
        const {id} = req.params;
        const eleve = await Eleve.findByIdAndDelete(id);
        if(!eleve){
            return res.status(404).json({message: `cannot find any eleve with ID ${id}`})
        }
        res.status(200).json(eleve);
    } catch(error) {
        res.status(500).json({message: error.message}) 
    }
})

mongoose.set("strictQuery", false)
mongoose.connect('mongodb://admin:devweb100@ac-tlfw3ny-shard-00-00.108eehp.mongodb.net:27017,ac-tlfw3ny-shard-00-01.108eehp.mongodb.net:27017,ac-tlfw3ny-shard-00-02.108eehp.mongodb.net:27017/EpiPFA?ssl=true&replicaSet=atlas-qe9d06-shard-0&authSource=admin&retryWrites=true&w=majority')
.then(() => {
    console.log('conneced to MongoDB')
    app.listen(3000, ()=> {
        console.log('node is running on port 3000')
    })
    
}).catch((error) => {
    console.log(error)
})